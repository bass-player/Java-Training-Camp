package com.imooc;

public class InitialTelephone {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Telephone phone = new Telephone();
		//phone.sendMessage();
		//��ʵ������ֵ
		phone.screen = 5.0f;
		phone.cpu = 1.4f;
		phone.mem =2.0f;
		//���ö���ķ���
		//phone.sendMessage();
		phone.call();
		System.out.println(phone.num);
	}

}
