package demo2;

public abstract class APerson {
	public abstract void say();
}
