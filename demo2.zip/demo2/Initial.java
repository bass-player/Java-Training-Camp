package demo2;

public class Initial {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		APerson p = new Chinese();
		APerson p2 = new American();
		p.say();
		p2.say();
	}
}
