package project3;

public class Cat extends Animal {
 
}
