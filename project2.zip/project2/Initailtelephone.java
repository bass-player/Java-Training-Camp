package project2;
import project3.Telephone;
public class Initailtelephone {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Telephone phone = new Telephone();
		//�вεĹ��췽�����Ը���ֵ
		/*Telephone phone2 = new Telephone(6.0f,1.4f,2.0f);
		//System.out.println(phone2.cpu+""+phone2.mem+""+phone2.screen);
		phone2.setScreen(3.8f);
		System.out.println("screen:"+phone2.getScreen());*/
	}

}
 