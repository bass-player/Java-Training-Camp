package animal;

public class Dog extends Animal {
	public void eat() {
		System.out.println("�����гԹ�ͷ������");
	}
	public void method() {
		eat();
	}
	@Override
	public String toString() {
		return "Dog [age=" + age + "]";
	}
	
}
