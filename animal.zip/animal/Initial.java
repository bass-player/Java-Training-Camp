package animal;

public class Initial{
	public void main(String[] args){
		Dog d = new Dog();
		d.age = 10;
		d.name = "xiaotian";
		d.eat();
	}
}
