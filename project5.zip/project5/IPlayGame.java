package project5;

public interface IPlayGame {
	public void playGame();
}
