package project5;

public abstract class Telphone {
 public abstract void call();
 public abstract void message();
}
