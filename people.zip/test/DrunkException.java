package com.imooc.test;

public class DrunkException extends Exception{

    public DrunkException(){

    }

    public DrunkException(String message){
        super(message);
    }
}
