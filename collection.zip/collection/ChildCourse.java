package com.imooc.collection;

public class ChildCourse extends Course {

}
