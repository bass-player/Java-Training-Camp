package com.imooc.collection;

import java.util.*;

public class CollectionsTest {

	//��integer���ͽ�������
	public void testSort1() {
		List<Integer> integerList = new ArrayList<Integer>();
		Random random = new Random();
		Integer k;
		for(int i=0;i<10;i++) {
			do{
			k = random.nextInt(100);
			}while(integerList.contains(k));
			integerList.add(k);
			System.out.println("�ɹ�����������"+ k);
		}
		System.out.println("---����ǰ---");
		for (Integer integer: integerList) {
			System.out.println("Ԫ�أ�"+integer);
		}
		Collections.sort(integerList);
		System.out.println("---�����---");
		for (Integer integer: integerList) {
			System.out.println("Ԫ�أ�"+integer);
		}
	}
	
	//��String���͵�List��������
	public void testSort2() {
		List<String> stringList = new ArrayList<String>();
		stringList.add("microsoft");
		stringList.add("google");
		stringList.add("lenovo");
		System.out.println("---����ǰ---");
		for(String string : stringList) {
			System.out.println("Ԫ�أ�"+ string);
		}
		Collections.sort(stringList);
		System.out.println("---�����---");
		for(String string : stringList) {
			System.out.println("Ԫ�أ�"+ string);
		}
	}
	
	public void testSort3() {
		List<Studeng> studentList = new ArrayList<Studeng>();
		Random random = new Random();
		studentList.add(new Studeng(random.nextInt(1000)+"","Mike"));
		studentList.add(new Studeng(random.nextInt(1000)+"","Angela"));
		studentList.add(new Studeng(random.nextInt(1000)+"","Lucy"));
		studentList.add(new Studeng(10000+"","Beyonce "));
		System.out.println("---����ǰ---");
		for(Studeng student : studentList) {
			System.out.println("ѧ����"+student.id+":"+student.name);
		}
		Collections.sort(studentList);
		System.out.println("---�����---");
		for(Studeng student : studentList) { 
			System.out.println("ѧ����"+student.id+":"+student.name);
		}
		Collections.sort(studentList, new StudentComparator());
		System.out.println("------������������-------");
		for(Studeng student : studentList) { 
			System.out.println("ѧ����"+student.id+":"+student.name);
		}
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CollectionsTest ct = new CollectionsTest();
		//ct.testSort1();
		//ct.testSort2();
		ct.testSort3(); 
	}
	

}
