package com.imooc.collection;

import java.util.Comparator;

public class StudentComparator implements Comparator<Studeng> {

	@Override
	public int compare(Studeng o1, Studeng o2) {
		// TODO Auto-generated method stub
		return o1.name.compareTo(o2.name);
	}

}
