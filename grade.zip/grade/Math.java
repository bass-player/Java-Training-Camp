package grade;

public class Math {

	public static void main(String[] args) {
		 double pi = 0;
	       	for (double i=1;i<1000000;i=i+2) {
	        	double a = i/2; //0,1,2
	        	if(a%2 > 0.5) {
	        		pi -= (1/i);
	        	}else {
	        		pi += (1/i);
	        	}	
	        }
	        pi = 4*pi;
	        System.out.println(pi);
	}
}
